<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="styles.css">
    <title>a21liltr</title>
</head>
<body>
<h1>Welcome Agent.</h1><br />

<form method="post" action="login.php">
    <label>USERNAME: </label><br>
    <input name="username" type="text"><br><br>

    <label>PASSWORD: </label><br>
    <input name="password" type="password"><br><br>

    <input type="submit" value="LOGIN">
</form>
</body>
</html>
